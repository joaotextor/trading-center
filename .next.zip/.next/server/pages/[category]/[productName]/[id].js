"use strict";
(() => {
var exports = {};
exports.id = 866;
exports.ids = [866];
exports.modules = {

/***/ 657:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Product),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: external "react-material-ui-carousel"
const external_react_material_ui_carousel_namespaceObject = require("react-material-ui-carousel");
var external_react_material_ui_carousel_default = /*#__PURE__*/__webpack_require__.n(external_react_material_ui_carousel_namespaceObject);
// EXTERNAL MODULE: ./src/templates/Default.js + 2 modules
var Default = __webpack_require__(6804);
// EXTERNAL MODULE: ./src/utils/dbConnect.js
var dbConnect = __webpack_require__(6190);
// EXTERNAL MODULE: ./src/models/products.js
var products = __webpack_require__(3553);
// EXTERNAL MODULE: ./src/utils/formatCurrency.js
var formatCurrency = __webpack_require__(2362);
;// CONCATENATED MODULE: ./pages/[category]/[productName]/[id].js







const MyBox = (0,material_.styled)(material_.Box)(({ theme  })=>({
        backgroundColor: theme.palette.background.white,
        padding: theme.spacing(3),
        marginBottom: theme.spacing(3),
        ["&.boxLocation"]: {
            marginTop: theme.spacing(3)
        }
    }));
const classes = {
    productName: {
        marginBlock: 2
    },
    productPrice: {
        fontWeight: "bold",
        marginBottom: 2
    },
    box: {
        padding: 3
    },
    card: {
        height: "100%"
    },
    cardMedia: {
        paddingTop: "56%"
    },
    carouselNavButtons: {
        color: "white"
    },
    location: {
        fontSize: "18px"
    }
};
function Product({ product  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(Default/* default */.Z, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
            maxWidth: "lg",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                container: true,
                spacing: 3,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        item: true,
                        xs: 8,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(MyBox, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_material_ui_carousel_default()), {
                                    autoPlay: false,
                                    animation: "slide",
                                    navButtonsAlwaysVisible: true,
                                    navButtonsProps: {
                                        style: classes.carouselNavButtons
                                    },
                                    children: product.files.map((file)=>/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Card, {
                                                sx: classes.card,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.CardMedia, {
                                                    sx: classes.cardMedia,
                                                    image: `/uploads/${file.name}`,
                                                    title: product.title
                                                })
                                            }, file.name)
                                        }))
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MyBox, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        component: "span",
                                        variant: "caption",
                                        children: `Publish on ${new Date(product.publishDate).toLocaleDateString("en-CA", {
                                            year: "numeric",
                                            month: "long",
                                            day: "numeric"
                                        })}`
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        component: "h4",
                                        variant: "h4",
                                        sx: classes.productName,
                                        children: product.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        component: "h4",
                                        variant: "h4",
                                        sx: classes.productPrice,
                                        children: (0,formatCurrency/* default */.Z)(product.price, "CA")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Chip, {
                                        label: product.category
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MyBox, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        component: "h6",
                                        variant: "h6",
                                        children: "Description"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        component: "p",
                                        variant: "body2",
                                        sx: classes.productName,
                                        children: product.description
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        item: true,
                        xs: 4,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Card, {
                                elevation: 0,
                                sx: classes.box,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.CardHeader, {
                                        avatar: //It works with only src={product.contactImage}, but throws a CastError: Cast to ObjectId failed for value "null"
                                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Avatar, {
                                            src: product.contactImage != "null" ? product.contactImage : "",
                                            children: product.contactImage === "null" && product.contactName[0].toUpperCase()
                                        }),
                                        title: product.contactName,
                                        subheader: product.contactEmail
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.CardMedia, {
                                        image: product.contactImage,
                                        title: product.contactName
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MyBox, {
                                className: "boxLocation",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        component: "span",
                                        variant: "h6",
                                        children: "Location:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        component: "span",
                                        variant: "body1",
                                        sx: classes.location,
                                        children: ` ${product.location}`
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
}
async function getServerSideProps({ query  }) {
    const { id  } = query;
    await (0,dbConnect/* default */.Z)();
    const product = await products/* default.findOne */.Z.findOne({
        _id: id
    });
    try {
        return {
            props: {
                product: JSON.parse(JSON.stringify(product))
            }
        };
    } catch  {
        return {
            props: {
                null: null
            }
        };
    }
}


/***/ }),

/***/ 7915:
/***/ ((module) => {

module.exports = require("@mui/icons-material");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,804,408], () => (__webpack_exec__(657)));
module.exports = __webpack_exports__;

})();