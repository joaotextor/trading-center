"use strict";
(() => {
var exports = {};
exports.id = 829;
exports.ids = [829];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 5616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 9063:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var _src_controllers_users__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8078);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const route = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])();
route.get(_src_controllers_users__WEBPACK_IMPORTED_MODULE_1__/* .user.get */ .E.get);
route.post(_src_controllers_users__WEBPACK_IMPORTED_MODULE_1__/* .user.post */ .E.post);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (route);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8078:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ user)
/* harmony export */ });
/* harmony import */ var _utils_dbConnect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7831);
/* harmony import */ var _src_models_users__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3317);
/* harmony import */ var _utils_password__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9025);



const user = {
    get: async (req, res)=>{
        await (0,_utils_dbConnect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
        const users = await _src_models_users__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find();
        res.status(200).json({
            success: true,
            users
        });
    },
    post: async (req, res)=>{
        const { name , email , password  } = req.body;
        await (0,_utils_dbConnect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
        const passwordCrypto = await (0,_utils_password__WEBPACK_IMPORTED_MODULE_2__/* .crypto */ .e)(password);
        const user = new _src_models_users__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z({
            name,
            email,
            password: passwordCrypto
        });
        user.save();
        res.status(201).json({
            success: true
        });
    }
};



/***/ }),

/***/ 3317:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const schema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    name: {
        type: String,
        required: [
            true,
            '"name" field is required'
        ]
    },
    email: {
        type: String,
        required: [
            true,
            '"email" field is required'
        ]
    },
    password: {
        type: String,
        required: [
            true,
            '"password" field is required'
        ]
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.users) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("users", schema));


/***/ }),

/***/ 9025:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "q": () => (/* binding */ compare),
  "e": () => (/* binding */ password_crypto)
});

;// CONCATENATED MODULE: external "bcrypt"
const external_bcrypt_namespaceObject = require("bcrypt");
var external_bcrypt_default = /*#__PURE__*/__webpack_require__.n(external_bcrypt_namespaceObject);
;// CONCATENATED MODULE: ./src/utils/password.js

async function password_crypto(pwd) {
    const salt = await external_bcrypt_default().genSalt();
    const password = await external_bcrypt_default().hash(pwd, salt);
    return password;
}
async function compare(pwd, hash) {
    const result = await external_bcrypt_default().compare(pwd, hash);
    return result;
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [831], () => (__webpack_exec__(9063)));
module.exports = __webpack_exports__;

})();