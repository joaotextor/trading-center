"use strict";
(() => {
var exports = {};
exports.id = 65;
exports.ids = [65];
exports.modules = {

/***/ 2446:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Login),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__(2296);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: ./src/templates/Default.js + 2 modules
var Default = __webpack_require__(6804);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(5609);
;// CONCATENATED MODULE: ./src/lib/formValues/signin/formValues.js

const initialValues = {
    email: "",
    password: ""
};
const validationSchema = external_yup_.object().shape({
    email: external_yup_.string().email("Insert a valid email address").required("Mandatory field."),
    password: external_yup_.string().required("Mandatory field.")
});


;// CONCATENATED MODULE: ./styles/signin/styles.js
const classes = {
    container: {
        marginBottom: 5
    },
    box: {
        backgroundColor: "white",
        padding: 3
    },
    formControl: {
        marginBottom: 2
    },
    inputLabel: {
        fontWeight: 400,
        marginLeft: -1.5
    },
    submit: {
        marginTop: 2
    },
    loading: {
        display: "block",
        margin: "10px auto"
    },
    errorMessage: {
        marginBlock: "0 20px"
    },
    orSeparator: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#e8e8e8",
        width: "100%",
        height: "1px",
        margin: "7 0 4",
        "& span": {
            backgroundColor: "white",
            padding: "0 30px"
        }
    },
    googleLoginButton: {
        marginInline: "0",
        marginBottom: "20px"
    }
};


// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./pages/auth/signin/index.js









function Login({ APP_URL  }) {
    const router = (0,router_.useRouter)();
    const { data: session , status  } = (0,react_.useSession)();
    const handleFormSubmit = async (values)=>{
        const signInStatus = await (0,react_.signIn)("credentials", {
            email: values.email,
            password: values.password,
            redirect: false
        });
        if (signInStatus.ok == false) {
            return router.push(`${APP_URL}/auth/signin?i=1`);
        }
        router.push(`${APP_URL}/user/dashboard`);
    };
    const handleGoogleLogin = async ()=>{
        await (0,react_.signIn)("google", {
            redirect: true,
            callbackUrl: `${APP_URL}/user/dashboard`
        });
    };
    if (status === "authenticated") {
        router.push(`${APP_URL}/user/dashboard`);
    } else {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Default/* default */.Z, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
                    maxWidth: "lg",
                    component: "main",
                    sx: classes.container,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        component: "h1",
                        variant: "h2",
                        align: "center",
                        color: "primary",
                        children: "Login to your account"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
                    maxWidth: "xs",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                        sx: classes.box,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                sx: classes.googleLoginButton,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                    variant: "contained",
                                    color: "primary",
                                    fullWidth: true,
                                    startIcon: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/images/logo_google.svg",
                                        alt: "google",
                                        width: 20,
                                        height: 20
                                    }),
                                    onClick: handleGoogleLogin,
                                    children: "Login with Google"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                sx: classes.orSeparator,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "OR"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Formik, {
                                initialValues: initialValues,
                                validationSchema: validationSchema,
                                onSubmit: handleFormSubmit,
                                children: ({ touched , values , errors , handleChange , handleSubmit , isSubmitting  })=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                        onSubmit: handleSubmit,
                                        children: [
                                            router.query.i == 1 ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Alert, {
                                                severity: "error",
                                                sx: classes.errorMessage,
                                                children: "Incorrect e-mail or password!"
                                            }) : null,
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.FormControl, {
                                                fullWidth: true,
                                                error: errors.email && touched.email,
                                                sx: classes.formControl,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.InputLabel, {
                                                        sx: classes.inputLabel,
                                                        children: "E-mail"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Input, {
                                                        name: "email",
                                                        value: values.email,
                                                        onChange: handleChange
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.FormHelperText, {
                                                        children: errors.email && touched.email ? errors.email : null
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.FormControl, {
                                                fullWidth: true,
                                                error: errors.password && touched.password,
                                                sx: classes.formControl,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.InputLabel, {
                                                        sx: classes.inputLabel,
                                                        children: "Password"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Input, {
                                                        type: "password",
                                                        name: "password",
                                                        value: values.password,
                                                        onChange: handleChange
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(material_.FormHelperText, {
                                                        children: errors.password && touched.password ? errors.password : null
                                                    })
                                                ]
                                            }),
                                            isSubmitting ? /*#__PURE__*/ jsx_runtime_.jsx(material_.CircularProgress, {
                                                sx: classes.loading
                                            }) : /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                                type: "submit",
                                                fullWidth: true,
                                                variant: "contained",
                                                color: "primary",
                                                disabled: isSubmitting,
                                                sx: classes.submit,
                                                children: "Signin"
                                            })
                                        ]
                                    });
                                }
                            })
                        ]
                    })
                })
            ]
        });
    }
}
async function getServerSideProps(context) {
    const APP_URL = await process.env.APP_URL;
    return {
        props: {
            APP_URL
        }
    };
}


/***/ }),

/***/ 7915:
/***/ ((module) => {

module.exports = require("@mui/icons-material");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,121,675,804], () => (__webpack_exec__(2446)));
module.exports = __webpack_exports__;

})();