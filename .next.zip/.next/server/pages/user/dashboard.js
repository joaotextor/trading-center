"use strict";
(() => {
var exports = {};
exports.id = 894;
exports.ids = [894];
exports.modules = {

/***/ 6911:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _src_utils_dbConnect__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6190);
/* harmony import */ var _src_models_products__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3553);
/* harmony import */ var _src_templates_Default__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6804);
/* harmony import */ var _src_utils_formatCurrency__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2362);
/* harmony import */ var _src_components_Card__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8009);
/* harmony import */ var _src_components_AlertDialog__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1182);
/* harmony import */ var _src_contexts_Toasty__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2491);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];














const PREFIX = "Dashboard";
const classes = {
    container: `${PREFIX}-container`,
    button: `${PREFIX}-buttonAdd`,
    card: `${PREFIX}-card`
};
const MyContainer = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Container)(({ theme  })=>({
        marginTop: 20,
        [`& .${classes.button}`]: {
            margin: "30px auto",
            display: "block",
            borderRadius: theme.shape.radius
        },
        [`& .${classes.card}`]: {
            padding: 5
        }
    }));
const MyLink = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.styled)((next_link__WEBPACK_IMPORTED_MODULE_3___default()))(({ theme  })=>({
        textDecoration: "none"
    }));
const Home = ({ products  })=>{
    const route = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const [alertOpen, setAlertOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [productToRemove, setProductToRemove] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { setToasty  } = (0,_src_contexts_Toasty__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const handleCloseModal = ()=>setAlertOpen(false);
    const handleOpenModal = (productId)=>{
        setProductToRemove(productId);
        setAlertOpen(true);
    };
    const handleRemoveProduct = ()=>{
        axios__WEBPACK_IMPORTED_MODULE_2__["default"]["delete"]("/api/products/delete", {
            data: {
                id: productToRemove
            }
        }).then(handleSuccess).catch(handleError);
    };
    const handleSuccess = ()=>{
        next_router__WEBPACK_IMPORTED_MODULE_5___default().reload(window, location.pathname);
        setAlertOpen(false);
        setToasty({
            open: true,
            severity: "success",
            text: "Ad removed successfully"
        });
    };
    const handleError = ()=>{
        setToasty({
            open: true,
            severity: "error",
            text: "Error removing Ad"
        });
        setAlertOpen(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_src_templates_Default__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_AlertDialog__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                open: alertOpen,
                onClose: handleCloseModal,
                action: handleRemoveProduct,
                title: "Delete Product",
                description: "Confirm deletion?",
                firstBtnText: "Disagree",
                secondBtnText: "Agree"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Container, {
                maxWidth: "sm",
                align: "center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {
                        component: "h1",
                        variant: "h2",
                        align: "center",
                        children: "My Adds"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MyLink, {
                        href: "/user/publish",
                        passHref: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Button, {
                            variant: "contained",
                            color: "primary",
                            sx: {
                                margin: 2
                            },
                            children: "Publish Add"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MyContainer, {
                maxWidth: "md",
                className: classes.card,
                children: [
                    products.length === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {
                        component: "div",
                        variant: "body1",
                        align: "center",
                        color: "primary",
                        gutterBottom: true,
                        children: "No Ad has been published yet."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                        container: true,
                        spacing: 2,
                        children: products.map((product)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                item: true,
                                xs: 12,
                                sm: 6,
                                md: 3,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Card__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    title: product.title,
                                    subtitle: (0,_src_utils_formatCurrency__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(product.price, "CA"),
                                    image: `/uploads/${product.files[0].name}`,
                                    actions: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                                size: "small",
                                                variant: "contained",
                                                color: "primary",
                                                onClick: ()=>route.push(`/user/edit/${product._id}`),
                                                children: "Edit"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                                size: "small",
                                                variant: "contained",
                                                color: "primary",
                                                onClick: ()=>handleOpenModal(product._id),
                                                children: "Remove"
                                            })
                                        ]
                                    })
                                })
                            }, product._id);
                        })
                    })
                ]
            })
        ]
    });
};
Home.requireAuth = true;
async function getServerSideProps({ req  }) {
    try {
        const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_4__.getSession)({
            req
        });
        await (0,_src_utils_dbConnect__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
        const products = await _src_models_products__WEBPACK_IMPORTED_MODULE_8__/* ["default"].find */ .Z.find({
            "userId": session.userId
        });
        return {
            props: {
                products: JSON.parse(JSON.stringify(products))
            }
        };
    } catch  {
        return {
            props: {
                null: null
            }
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7915:
/***/ ((module) => {

module.exports = require("@mui/icons-material");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 8611:
/***/ ((module) => {

module.exports = require("@mui/material/Dialog");

/***/ }),

/***/ 9404:
/***/ ((module) => {

module.exports = require("@mui/material/DialogActions");

/***/ }),

/***/ 1094:
/***/ ((module) => {

module.exports = require("@mui/material/DialogContent");

/***/ }),

/***/ 2268:
/***/ ((module) => {

module.exports = require("@mui/material/DialogContentText");

/***/ }),

/***/ 2468:
/***/ ((module) => {

module.exports = require("@mui/material/DialogTitle");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,804,408,491,514], () => (__webpack_exec__(6911)));
module.exports = __webpack_exports__;

})();