"use strict";
(() => {
var exports = {};
exports.id = 2;
exports.ids = [2];
exports.modules = {

/***/ 2169:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _src_templates_Default__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6804);
/* harmony import */ var _src_models_products__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3553);
/* harmony import */ var _src_lib_formValues_edit_formValues__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7997);
/* harmony import */ var _src_contexts_Toasty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2491);
/* harmony import */ var _src_utils_formatCurrency__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2362);
/* harmony import */ var _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7411);
/* harmony import */ var _src_components_FileUpload__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5669);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9648);
/* harmony import */ var _src_utils_dbConnect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6190);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_11__]);
axios__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];















const Edit = ({ product  })=>{
    const { setToasty  } = (0,_src_contexts_Toasty__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const formValues = {
        productId: `${product._id}`,
        title: `${product.title}`,
        category: `${product.category}`,
        description: `${product.description}`,
        price: `${(0,_src_utils_formatCurrency__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(product.price, "")}`,
        contactName: `${product.contactName}`,
        contactEmail: `${product.contactEmail}`,
        contactPhone: `${product.contactPhone}`,
        files: product.files,
        location: `${product.location}`,
        filesToRemove: []
    };
    const handleSuccess = ()=>{
        setToasty({
            open: true,
            text: "Advertisement edited successfully",
            severity: "success"
        });
        router.push("/user/dashboard");
    };
    const handleError = ()=>{
        setToasty({
            open: true,
            text: "A problem occurred! Please, try again.",
            severity: "error"
        });
    };
    const handleFormSubmit = async (values)=>{
        //JS method to send form values to the server
        const formData = new FormData();
        for(let field in values){
            if (field === "files") {
                values.files.forEach((file)=>{
                    formData.append("files", file);
                });
            } else {
                formData.append(field, values[field]);
            }
        }
        await axios__WEBPACK_IMPORTED_MODULE_11__["default"].put("/api/products/put/", formData).then(handleSuccess).catch(handleError);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_templates_Default__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
            initialValues: formValues,
            validationSchema: _src_lib_formValues_edit_formValues__WEBPACK_IMPORTED_MODULE_7__/* .validationSchema */ .p,
            onSubmit: handleFormSubmit,
            children: ({ touched , values , errors , handleChange , handleSubmit , setFieldValue , isSubmitting  })=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    onSubmit: handleSubmit,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Input, {
                            type: "hidden",
                            value: product._id,
                            name: "productId"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Input, {
                            type: "hidden",
                            value: values.filesToRemove,
                            name: "filesToRemove"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Container, {
                            className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.container */ .S.container,
                            maxWidth: "sm",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                    component: "h1",
                                    variant: "h2",
                                    align: "center",
                                    color: "primary",
                                    children: "Publish new Ad"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                    component: "h5",
                                    variant: "h5",
                                    align: "center",
                                    color: "primary",
                                    children: "The more detailed the better!"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .MyContainer */ .p, {
                            maxWidth: "md",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.box */ .S.box,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormControl, {
                                        error: errors.title && touched.title,
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.InputLabel, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.inputLabel */ .S.inputLabel,
                                                children: "Ad Title"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Input, {
                                                name: "title",
                                                variant: "standard",
                                                value: values.title,
                                                onChange: handleChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormHelperText, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.helperText */ .S.helperText,
                                                children: errors.title && touched.title ? errors.title : null
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormControl, {
                                        error: errors.category && touched.category,
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.InputLabel, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.inputLabel */ .S.inputLabel,
                                                children: "Category"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Select, {
                                                name: "category",
                                                value: values.category,
                                                fullWidth: true,
                                                onChange: handleChange,
                                                variant: "standard",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Babies and Children",
                                                        children: "Babies and Children"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Agriculture",
                                                        children: "Agriculture"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Fashion",
                                                        children: "Fashion"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Cars, Motorcycles and Boats",
                                                        children: "Cars, Motorcycles and Boats"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Services",
                                                        children: "Services"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Recreation",
                                                        children: "Recreation"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Animals",
                                                        children: "Animals"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Furniture, Home and Garden",
                                                        children: "Furniture, Home and Garden"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Real Estate",
                                                        children: "Real Estate"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Equipments and Tools",
                                                        children: "Equipments and Tools"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Smartphones and Tablets",
                                                        children: "Smartphones and Tablets"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Sport",
                                                        children: "Sport"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Technology",
                                                        children: "Technology"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Jobs",
                                                        children: "Jobs"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                                        value: "Other",
                                                        children: "Other"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormHelperText, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.helperText */ .S.helperText,
                                                children: errors.category && touched.category ? errors.category : null
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .MyContainer */ .p, {
                            className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.container */ .S.container,
                            maxWidth: "md",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.box */ .S.box,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_FileUpload__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    files: values.files,
                                    filesToRemove: values.filesToRemove,
                                    errors: errors.files,
                                    touched: touched.files,
                                    setFieldValue: setFieldValue
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .MyContainer */ .p, {
                            className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.container */ .S.container,
                            maxWidth: "md",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.box */ .S.box,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormControl, {
                                    error: errors.description && touched.description,
                                    fullWidth: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.InputLabel, {
                                            sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.inputLabel */ .S.inputLabel,
                                            children: "Write the details of what you are selling."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Input, {
                                            className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.detailsField */ .S.detailsField,
                                            multiline: true,
                                            name: "description",
                                            onChange: handleChange,
                                            value: values.description,
                                            rows: 6,
                                            variant: "outlined"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormHelperText, {
                                            sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.helperText */ .S.helperText,
                                            children: errors.description && touched.description ? errors.description : null
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .MyContainer */ .p, {
                            className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.container */ .S.container,
                            maxWidth: "md",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.box */ .S.box,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormControl, {
                                    variant: "standard",
                                    fullWidth: true,
                                    error: errors.price && touched.price,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.InputLabel, {
                                            variant: "outlined",
                                            sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.inputLabel */ .S.inputLabel,
                                            children: "Price"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Input, {
                                            name: "price",
                                            label: "Value" //without this prop, the outline will be above the InputLabel's value (Value). Another approch would set the InputLabel's background to white, but this wont add a space before and after the label (like an inline margin), making it look weird.
                                            ,
                                            value: values.price,
                                            onChange: handleChange,
                                            startAdornment: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.InputAdornment, {
                                                position: "start",
                                                children: "C$"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormHelperText, {
                                            sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.helperText */ .S.helperText,
                                            children: errors.price && touched.price ? errors.price : null
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .MyContainer */ .p, {
                            className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.container */ .S.container,
                            maxWidth: "md",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.box */ .S.box,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        component: "h6",
                                        variant: "h6",
                                        color: "primary",
                                        gutterBottom: true,
                                        children: "Contact Info"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormControl, {
                                        error: errors.contactName && touched.contactName,
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.InputLabel, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.inputLabel */ .S.inputLabel,
                                                children: "Contact Name"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Input, {
                                                name: "contactName",
                                                value: values.contactName,
                                                onChange: handleChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormHelperText, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.helperText */ .S.helperText,
                                                children: errors.contactName && touched.contactName ? errors.contactName : null
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormControl, {
                                        error: errors.contactEmail && touched.contactEmail,
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.InputLabel, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.inputLabel */ .S.inputLabel,
                                                children: "Email"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Input, {
                                                name: "contactEmail",
                                                value: values.contactEmail,
                                                onChange: handleChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormHelperText, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.helperText */ .S.helperText,
                                                children: errors.contactEmail && touched.contactEmail ? errors.contactEmail : null
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormControl, {
                                        error: errors.contactPhone && touched.contactPhone,
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.InputLabel, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.inputLabel */ .S.inputLabel,
                                                children: "Phone"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Input, {
                                                name: "contactPhone",
                                                value: values.contactPhone,
                                                onChange: handleChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormHelperText, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.helperText */ .S.helperText,
                                                children: errors.contactPhone && touched.contactPhone ? errors.contactPhone : null
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormControl, {
                                        error: errors.location && touched.location,
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.InputLabel, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.inputLabel */ .S.inputLabel,
                                                children: "Location"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Input, {
                                                name: "location",
                                                value: values.location,
                                                onChange: handleChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.FormHelperText, {
                                                sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.helperText */ .S.helperText,
                                                children: errors.location && touched.location ? errors.location : null
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .MyContainer */ .p, {
                            className: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.container */ .S.container,
                            maxWidth: "md",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                display: "flex",
                                justifyContent: "right",
                                children: isSubmitting ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.CircularProgress, {
                                    sx: _styles_edit_styles__WEBPACK_IMPORTED_MODULE_9__/* .classes.loading */ .S.loading
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                    variant: "contained",
                                    color: "primary",
                                    type: "submit",
                                    children: "Publish Ad"
                                })
                            })
                        })
                    ]
                });
            }
        })
    });
};
Edit.requireAuth = true;
async function getServerSideProps({ query  }) {
    const { id  } = query;
    await (0,_src_utils_dbConnect__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const product = await _src_models_products__WEBPACK_IMPORTED_MODULE_6__/* ["default"].findOne */ .Z.findOne({
        _id: id
    });
    try {
        return {
            props: {
                product: JSON.parse(JSON.stringify(product))
            }
        };
    } catch  {
        return {
            props: {
                null: null
            }
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Edit);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ validationSchema)
/* harmony export */ });
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_0__);

const validationSchema = yup__WEBPACK_IMPORTED_MODULE_0__.object().shape({
    title: yup__WEBPACK_IMPORTED_MODULE_0__.string().min(6, "Write a longer title").max(100, "Title too large").required("Mandatory field"),
    category: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Mandatory field"),
    description: yup__WEBPACK_IMPORTED_MODULE_0__.string().min(50, "Write a description with at least 50 characters").required("Mandatory field"),
    price: yup__WEBPACK_IMPORTED_MODULE_0__.number().required("Mandatory field"),
    contactName: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Mandatory field"),
    contactEmail: yup__WEBPACK_IMPORTED_MODULE_0__.string().email("Insert a valid email address").required("Mandatory field"),
    contactPhone: yup__WEBPACK_IMPORTED_MODULE_0__.number("Phone must contain only numbers.").required("Mandatory field"),
    files: yup__WEBPACK_IMPORTED_MODULE_0__.array().min(1, "Submit at least one image").required("Mandatory field"),
    location: yup__WEBPACK_IMPORTED_MODULE_0__.string().required("Mandatory field")
});



/***/ }),

/***/ 7411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ classes),
/* harmony export */   "p": () => (/* binding */ MyContainer)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const PREFIX = "Publish";
const classes = {
    container: `${PREFIX}-container`,
    box: `${PREFIX}-box`,
    detailsField: `${PREFIX}-details-field`,
    dropZone: `${PREFIX}-dropZone`,
    thumbImage: `${PREFIX}-thumb-image`,
    thumbMask: `${PREFIX}-thumb-mask`,
    labelMainImage: `${PREFIX}-label-main-image`,
    inputLabel: {
        fontWeight: 400,
        marginLeft: -1.5
    },
    helperText: {
        marginLeft: 0
    },
    loading: {
        display: "block",
        margin: "10px"
    }
};
const MyContainer = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Container)(({ theme  })=>({
        marginTop: 30,
        [`& .${classes.box}`]: {
            padding: 20,
            backgroundColor: theme.palette.background.white,
            boxShadow: "5px 5px 15px grey"
        },
        [`& .${classes.detailsField}`]: {
            marginTop: 10
        }
    }));



/***/ }),

/***/ 7915:
/***/ ((module) => {

module.exports = require("@mui/icons-material");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 6358:
/***/ ((module) => {

module.exports = require("react-dropzone");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,804,408,491,669], () => (__webpack_exec__(2169)));
module.exports = __webpack_exports__;

})();