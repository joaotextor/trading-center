"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 8889:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ MyApp)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: external "prop-types"
const external_prop_types_namespaceObject = require("prop-types");
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_namespaceObject);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
;// CONCATENATED MODULE: external "@mui/material/CssBaseline"
const CssBaseline_namespaceObject = require("@mui/material/CssBaseline");
var CssBaseline_default = /*#__PURE__*/__webpack_require__.n(CssBaseline_namespaceObject);
// EXTERNAL MODULE: ./src/contexts/Toasty.js + 1 modules
var Toasty = __webpack_require__(2491);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: ./src/theme.js
var theme = __webpack_require__(5291);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/components/CheckAuth/styles.js
const classes = {
    box: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh"
    }
};

;// CONCATENATED MODULE: ./src/components/CheckAuth/index.js






const CheckAuth = ({ Component , pageProps  })=>{
    const { data: session , status  } = (0,react_.useSession)();
    const router = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        if (!session) {
            router.push("/auth/signin");
        }
    }, [
        router,
        session
    ]);
    if (session) {
        return /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        sx: classes.box,
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
            variant: "h3",
            component: "h1",
            children: "Loading..."
        })
    });
};
/* harmony default export */ const components_CheckAuth = (CheckAuth);

;// CONCATENATED MODULE: ./pages/_app.js










function MyApp(props) {
    const { Component , pageProps  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Trading Center"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "minimum-scale=1, initial-scale=1, width=device-width"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.SessionProvider, {
                session: pageProps.session,
                children: /*#__PURE__*/ jsx_runtime_.jsx(styles_.ThemeProvider, {
                    theme: theme/* default */.Z,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Toasty/* ToastyProvider */.U, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((CssBaseline_default()), {}),
                            Component.requireAuth ? /*#__PURE__*/ jsx_runtime_.jsx(components_CheckAuth, {
                                Component: Component,
                                pageProps: pageProps
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                                ...pageProps
                            })
                        ]
                    })
                })
            })
        ]
    });
}
MyApp.propTypes = {
    Component: (external_prop_types_default()).elementType.isRequired,
    pageProps: (external_prop_types_default()).object.isRequired
};


/***/ }),

/***/ 5291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);

const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.createTheme)({
    palette: {
        primary: {
            main: "#000000"
        },
        secondary: {
            main: "#FFFFFF"
        },
        background: {
            default: "rgb(242, 244, 245)",
            white: "#ffffff",
            variantion: "red",
            blackTransparent: "rgba(0, 0, 0, .7)"
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (theme);


/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [491], () => (__webpack_exec__(8889)));
module.exports = __webpack_exports__;

})();