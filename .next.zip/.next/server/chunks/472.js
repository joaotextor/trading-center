"use strict";
exports.id = 472;
exports.ids = [472];
exports.modules = {

/***/ 472:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SearchBar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/SearchBar/styles.js

const SearchBox = (0,material_.styled)(material_.Paper)(({ theme  })=>({
        display: "flex",
        justifyContent: "center",
        padding: theme.spacing(0.2),
        paddingLeft: 10,
        marginTop: 20
    }));


// EXTERNAL MODULE: external "@mui/icons-material/Search"
var Search_ = __webpack_require__(8017);
var Search_default = /*#__PURE__*/__webpack_require__.n(Search_);
// EXTERNAL MODULE: ./src/components/AlertDialog/index.js
var AlertDialog = __webpack_require__(1182);
;// CONCATENATED MODULE: ./src/components/SearchBar/index.js







function SearchBar() {
    const route = (0,router_.useRouter)();
    const [search, setSearch] = (0,external_react_.useState)();
    const [alertOpen, setAlertOpen] = (0,external_react_.useState)(false);
    const handleSubmitSearch = ()=>{
        if (search == undefined) {
            return setAlertOpen(true);
        }
        route.push(`/search/${search}`);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(AlertDialog/* default */.Z, {
                open: alertOpen,
                onClose: ()=>setAlertOpen(false),
                title: "Search query empty",
                description: "Please enter something to search!",
                firstBtnText: "OK"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(SearchBox, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.InputBase, {
                        error: true,
                        onChange: (e)=>setSearch(e.target.value),
                        onKeyDown: (e)=>{
                            if (e.key === "Enter") {
                                handleSubmitSearch();
                            }
                        },
                        placeholder: "Ex.: iPhone 13 with warranty",
                        fullWidth: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                        onClick: handleSubmitSearch,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Search_default()), {})
                    })
                ]
            })
        ]
    });
}


/***/ })

};
;