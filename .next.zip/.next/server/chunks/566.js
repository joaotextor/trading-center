"use strict";
exports.id = 566;
exports.ids = [566];
exports.modules = {

/***/ 566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "O": () => (/* binding */ product)
});

// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(1017);
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_);
// EXTERNAL MODULE: external "fs"
var external_fs_ = __webpack_require__(7147);
var external_fs_default = /*#__PURE__*/__webpack_require__.n(external_fs_);
// EXTERNAL MODULE: ./src/utils/dbConnect.js
var dbConnect = __webpack_require__(7831);
// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(5609);
;// CONCATENATED MODULE: ./src/models/products.js


const filesSchema = new (external_mongoose_default()).Schema({
    name: String,
    path: String
});
const schema = new (external_mongoose_default()).Schema({
    title: {
        type: String,
        required: [
            true,
            '"title" field is required'
        ]
    },
    category: {
        type: String,
        required: [
            true,
            '"category" field is required'
        ]
    },
    userId: {
        type: String
    },
    contactImage: {
        type: String
    },
    contactEmail: {
        type: String,
        required: [
            true,
            '"email" field is required'
        ]
    },
    contactName: {
        type: String,
        required: [
            true,
            '"contactName" field is required'
        ]
    },
    contactPhone: {
        type: Number,
        required: [
            true,
            '"contactPhone" field is required'
        ]
    },
    description: {
        type: String,
        required: [
            true,
            '"description" field is required'
        ]
    },
    price: {
        type: Number,
        required: [
            true,
            '"title" field is required'
        ]
    },
    files: {
        type: [
            filesSchema
        ],
        default: undefined
    },
    location: {
        type: String,
        default: "Location not informed."
    },
    publishDate: {
        type: Date,
        default: Date.now()
    }
});
/* harmony default export */ const products = ((external_mongoose_default()).models.products || external_mongoose_default().model("products", schema));

// EXTERNAL MODULE: external "formidable-serverless"
var external_formidable_serverless_ = __webpack_require__(1529);
var external_formidable_serverless_default = /*#__PURE__*/__webpack_require__.n(external_formidable_serverless_);
;// CONCATENATED MODULE: ./src/controllers/product.js





const product = {
    // get: async (req, res) => {
    //     await dbConnect()
    //     const products = await ProductsModel.find()
    //     res.status(200).json({ success: true, products})
    // },
    post: async (req, res)=>{
        await (0,dbConnect/* default */.Z)();
        const form = new (external_formidable_serverless_default()).IncomingForm({
            multiples: true,
            uploadDir: "public/uploads",
            keepExtensions: true
        });
        form.parse(req, async (error, fields, data)=>{
            if (error) {
                return res.status(500).json({
                    success: false
                });
            }
            const { files  } = data;
            const filesToRename = files instanceof Array ? files : [
                files
            ];
            const filesToSave = [];
            filesToRename.forEach((file)=>{
                const timestamp = Date.now();
                const random = Math.floor(Math.random() * 999999999) + 1;
                const extension = external_path_default().extname(file.name);
                const filename = `${timestamp}_${random}${extension}`;
                const oldpath = external_path_default().join(__dirname, `../../../../../${file.path}`);
                const newpath = external_path_default().join(__dirname, `../../../../../${form.uploadDir}/${filename}`);
                filesToSave.push({
                    name: filename,
                    path: newpath
                });
                external_fs_default().rename(oldpath, newpath, (error)=>{
                    if (error) {
                        return res.status(500).json({
                            success: false
                        });
                    }
                });
            });
            const { title , category , userId , contactImage , description , price , contactName , contactEmail , contactPhone , location , publishDate  } = fields;
            const product = new products({
                title,
                category,
                userId,
                contactImage,
                description,
                price,
                contactName,
                contactEmail,
                contactPhone,
                files: filesToSave,
                location,
                publishDate
            });
            const register = await product.save();
            if (register) {
                res.status(201).json({
                    success: true
                });
            } else {
                res.status(500).json({
                    success: false
                });
            }
        });
    },
    put: async (req, res)=>{
        await (0,dbConnect/* default */.Z)();
        const form = new (external_formidable_serverless_default()).IncomingForm({
            multiples: true,
            uploadDir: "public/uploads",
            keepExtensions: true
        });
        form.parse(req, async (error, fields, data)=>{
            const { productId , title , category , description , price , contactName , contactEmail , contactPhone , location , filesToRemove  } = fields;
            const product = await products.findById(productId);
            // Transform back the comma separated string into an Array
            const filesToRemoveArr = filesToRemove.split(",");
            if (error) {
                return res.status(500).json({
                    success: false
                });
            }
            const { files  } = data;
            const filesToSave = product.files.filter((f)=>!filesToRemoveArr.includes(f.path));
            if (files != undefined) {
                const filesToRename = files instanceof Array ? files : [
                    files
                ];
                filesToRename.forEach((file)=>{
                    const timestamp = Date.now();
                    const random = Math.floor(Math.random() * 999999999) + 1;
                    const extension = external_path_default().extname(file.name);
                    const filename = `${timestamp}_${random}${extension}`;
                    const oldpath = external_path_default().join(__dirname, `../../../../../${file.path}`);
                    const newpath = external_path_default().join(__dirname, `../../../../../${form.uploadDir}/${filename}`);
                    filesToSave.push({
                        name: filename,
                        path: newpath
                    });
                    external_fs_default().rename(oldpath, newpath, (error)=>{
                        if (error) {
                            return res.status(500).json({
                                success: false
                            });
                        }
                    });
                });
            }
            product.title = title;
            product.category = category;
            product.description = description;
            product.price = price;
            product.contactName = contactName;
            product.contactEmail = contactEmail;
            product.contactPhone = contactPhone;
            product.location = location;
            product.publishDate = Date.now();
            product.files = filesToSave;
            const register = await product.save();
            if (register) {
                filesToRemoveArr.forEach((file)=>{
                    external_fs_default().rm(file, {}, ()=>{});
                });
                res.status(201).json({
                    success: true
                });
            } else {
                res.status(500).json({
                    success: false
                });
            }
        });
    },
    delete: async (req, res)=>{
        await (0,dbConnect/* default */.Z)();
        const id = req.body.id;
        const deleted = await products.findOneAndRemove({
            _id: id
        });
        try {
            deleted.files.map((file)=>{
                const deletedFile = external_fs_default().rm(file.path, {}, ()=>{});
                return deletedFile;
            });
        } catch  {
            console.log("An error has occurred");
        }
        if (deleted) {
            return res.status(200).json({
                success: true
            });
        } else {
            return res.status(500).json({
                success: false
            });
        }
    }
};



/***/ })

};
;