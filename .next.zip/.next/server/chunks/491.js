"use strict";
exports.id = 491;
exports.ids = [491];
exports.modules = {

/***/ 2491:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "U": () => (/* binding */ ToastyProvider),
  "Z": () => (/* binding */ contexts_Toasty)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/Toasty/index.js


const Toasty = ({ open , text , severity , onClose =null  })=>{
    const handleClose = (event, reason)=>{
        if (reason === "clickaway") {
            return;
        }
        if (onClose) onClose();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Snackbar, {
        anchorOrigin: {
            vertical: "bottom",
            horizontal: "right"
        },
        open: open,
        autoHideDuration: 6000,
        onClose: handleClose,
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Alert, {
            elevation: 6,
            variant: "filled",
            severity: severity,
            children: text
        })
    });
};
/* harmony default export */ const components_Toasty = (Toasty);

;// CONCATENATED MODULE: ./src/contexts/Toasty.js



const ToastyContext = /*#__PURE__*/ (0,external_react_.createContext)({});
function ToastyProvider({ children  }) {
    const [toasty, setToasty] = (0,external_react_.useState)({
        open: false,
        text: "",
        severity: "info"
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ToastyContext.Provider, {
        value: {
            setToasty
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_Toasty, {
                open: toasty.open,
                severity: toasty.severity,
                text: toasty.text,
                onClose: ()=>setToasty({
                        ...toasty,
                        open: false
                    })
            }),
            children
        ]
    });
}
const useToasty = ()=>(0,external_react_.useContext)(ToastyContext);
/* harmony default export */ const contexts_Toasty = (useToasty);


/***/ })

};
;