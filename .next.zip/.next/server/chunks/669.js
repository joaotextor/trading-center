"use strict";
exports.id = 669;
exports.ids = [669];
exports.modules = {

/***/ 5669:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ FileUpload)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/icons-material"
var icons_material_ = __webpack_require__(7915);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/system"
var system_ = __webpack_require__(7986);
// EXTERNAL MODULE: external "react-dropzone"
var external_react_dropzone_ = __webpack_require__(6358);
;// CONCATENATED MODULE: ./src/components/FileUpload/styles.js

const ThumbBox = (0,material_.styled)(material_.Box)(({ theme  })=>({
        position: "relative",
        display: "flex",
        border: "2px solid black",
        padding: 10,
        margin: "0 15px 15px 0",
        justifyContent: "center",
        alignItems: "center",
        textAlign: "center",
        width: 200,
        height: 150,
        [`&.dropzone`]: {
            border: "2px dashed black",
            backgroundColor: theme.palette.background.default
        },
        [`&.thumb-img`]: {
            padding: 0,
            border: 0,
            backgroundSize: "contain",
            backgroundRepeat: "no-repeat"
        },
        [`& .thumb-mask`]: {
            display: "none",
            width: "100%",
            height: "100%",
            margin: 0,
            border: 0,
            backgroundColor: theme.palette.background.blackTransparent
        },
        [`&.thumb-img:hover .thumb-mask`]: {
            display: "flex"
        },
        [`& .lbl-main-img`]: {
            color: "white",
            margin: 0,
            border: 0,
            borderRadius: "5px",
            width: "fit-content",
            height: "20px",
            backgroundColor: "blue",
            padding: "6px 10px",
            position: "absolute",
            bottom: 0,
            left: 0
        }
    }));


;// CONCATENATED MODULE: ./src/components/FileUpload/index.js






function FileUpload({ files , filesToRemove , errors , touched , setFieldValue  }) {
    const { getRootProps , getInputProps  } = (0,external_react_dropzone_.useDropzone)({
        accept: "image/*",
        onDrop: (acceptedFile)=>{
            const newFiles = acceptedFile.map((file)=>Object.assign(file, {
                    preview: URL.createObjectURL(file)
                }));
            setFieldValue("files", [
                ...files,
                ...newFiles
            ]);
        }
    });
    //! Using only file.path will cause a bug in which if the user uploads 2 ore more files with the same name, all of them will be deleted at once when deleting one of them.
    const handleRemoveFile = (fileIndex, filePath)=>{
        const newFileState = files.filter((file, index)=>index + file.path !== `${fileIndex}${filePath}`);
        //This will append the removed file to the FilesToRemove array
        //When submited in FormData, it will be received as a String separated by commas
        //Then we just use split(',') to transform back into an Array
        setFieldValue("filesToRemove", [
            ...filesToRemove,
            filePath
        ]);
        setFieldValue("files", newFileState);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                component: "h6",
                variant: "h6",
                color: errors && touched ? "error" : "primary",
                children: "Images"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                component: "div",
                variant: "body2",
                color: errors && touched ? "error" : "primary",
                children: "The first image will be your ad's cover picture."
            }),
            errors && touched ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                variant: "body2",
                color: "error",
                gutterBottom: true,
                children: errors
            }) : null,
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(system_.Box, {
                sx: {
                    display: "flex",
                    flexWrap: "wrap",
                    marginTop: "10px"
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ThumbBox, {
                        className: "dropzone",
                        ...getRootProps(),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                ...getInputProps()
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                color: errors ? "error" : "primary",
                                children: "Click to select or drag image here"
                            })
                        ]
                    }),
                    files.map((file, index)=>{
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ThumbBox, {
                            className: "thumb-img",
                            sx: {
                                backgroundImage: file.preview ? `url(${file.preview})` : `url('/uploads/${file.name}')`,
                                backgroundPosition: "center"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(ThumbBox, {
                                    className: "thumb-mask",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.IconButton, {
                                        color: "secondary",
                                        onClick: ()=>handleRemoveFile(index, file.path),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(icons_material_.DeleteForever, {
                                            fontSize: "large"
                                        })
                                    })
                                }),
                                index === 0 ? /*#__PURE__*/ jsx_runtime_.jsx(ThumbBox, {
                                    className: "lbl-main-img",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                        children: "Main"
                                    })
                                }) : null
                            ]
                        }, file.preview ? `${file.path}-${index}` : `${file.name}`);
                    })
                ]
            })
        ]
    });
}


/***/ })

};
;