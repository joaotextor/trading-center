"use strict";
exports.id = 408;
exports.ids = [408];
exports.modules = {

/***/ 3553:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_1__);


const filesSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    name: String,
    path: String
});
const schema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    title: {
        type: String,
        required: [
            true,
            '"title" field is required'
        ]
    },
    category: {
        type: String,
        required: [
            true,
            '"category" field is required'
        ]
    },
    userId: {
        type: String
    },
    contactImage: {
        type: String
    },
    contactEmail: {
        type: String,
        required: [
            true,
            '"email" field is required'
        ]
    },
    contactName: {
        type: String,
        required: [
            true,
            '"contactName" field is required'
        ]
    },
    contactPhone: {
        type: Number,
        required: [
            true,
            '"contactPhone" field is required'
        ]
    },
    description: {
        type: String,
        required: [
            true,
            '"description" field is required'
        ]
    },
    price: {
        type: Number,
        required: [
            true,
            '"title" field is required'
        ]
    },
    files: {
        type: [
            filesSchema
        ],
        default: undefined
    },
    location: {
        type: String,
        default: "Location not informed."
    },
    publishDate: {
        type: Date,
        default: Date.now()
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.products) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("products", schema));


/***/ }),

/***/ 6190:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
    throw new Error("Please define the MONGODB_URI environment variable inside .env.local");
}
/**
 * Global is used here to maintain a cached connection across hot reloads in development. This prevents connections growing exponentially
 * during API Route usage.
 */ let cached = global.mongoose;
if (!cached) {
    cached = global.mongoose = {
        conn: null,
        promise: null
    };
}
async function dbConnect() {
    if (cached.conn) {
        return cached.conn;
    }
    if (!cached.promise) {
        const opts = {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            bufferCommands: false
        };
        cached.promise = mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(MONGODB_URI, opts).then((mongoose)=>{
            console.log("Connected to database!");
            return mongoose;
        });
    }
    cached.conn = await cached.promise;
    return cached.conn;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);


/***/ }),

/***/ 2362:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ formatCurrency)
/* harmony export */ });
function formatCurrency(value, countryCode) {
    switch(countryCode){
        case "CA":
            return "C" + value.toLocaleString("en-CA", {
                style: "currency",
                currency: "CAD"
            });
        case "US":
            return value.toLocaleString("US", {
                style: "currency",
                currency: "USD"
            });
        case "BR":
            return value.toLocaleString("BR", {
                style: "currency",
                currency: "BRL"
            });
        case "":
            return parseFloat(value).toFixed(2);
    }
}


/***/ })

};
;